console.log("Hello CLI!");
