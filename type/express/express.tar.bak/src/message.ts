export const message = {
  started: "Server running on port %d.",
} as const;
