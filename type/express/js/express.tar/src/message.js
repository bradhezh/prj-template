const message = {
  started: "Server running on port %d.",
};

module.exports = message;
