const hello = () => {
  return "Hello Express!";
};

module.exports = { hello };
