import { hello } from "@/.";

console.log(hello("library"));
