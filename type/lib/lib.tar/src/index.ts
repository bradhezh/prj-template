export const hello = (name: string) => {
  return `Hello ${name}!`;
};

console.log(hello("library"));
