const { hello } = require("./index");

console.log(hello("library"));
