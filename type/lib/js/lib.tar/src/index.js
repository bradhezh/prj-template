const hello = (name) => {
  return `Hello ${name}!`;
};

console.log(hello("library"));

module.exports = { hello };
