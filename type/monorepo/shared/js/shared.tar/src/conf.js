const env = {
  dev: "development",
  prod: "production",
  debug: "debug",
  test: "test",
};

const conf = {
  ep: {
    api: "/api",
  },
};

module.exports = { env, conf };
